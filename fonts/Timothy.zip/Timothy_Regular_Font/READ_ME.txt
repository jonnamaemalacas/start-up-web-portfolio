Hello,

Thank you for downloading Timothy Font: 
This font is FREE for PERSONAL AND COMMERCIAL USE! 
But any donation are very appreciated. 


Paypal account for donation : paypal.me/delisdesign 
visit my behance profile to follow new goods : https://www.behance.net/heydls

And follow my instagram for update : @heydls

If there is a problem, question, or anything about my font, please sent an email to
delis.design@mail.ru

Thanks,

Ksenya Zoltsman